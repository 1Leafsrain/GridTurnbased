using UnityEngine;

public class tesEnemy : MonoBehaviour
{
    public string enemyName = "slime";
    public int health = 10;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
